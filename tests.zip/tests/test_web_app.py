import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from model import MODEL_PATH, ROOT
from web_app import FruitLensHandler


class WebInterfaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), FruitLensHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def test_serves_standalone_interface(self):
        with urlopen(self.base_url) as response:
            page = response.read().decode("utf-8")
        self.assertIn("Give us a peek.", page)
        with urlopen(self.base_url + "/styles.css") as response:
            self.assertIn(b"backdrop-filter", response.read())
        with urlopen(self.base_url + "/fruit-backdrop.svg") as response:
            self.assertIn(b"id=\"banana\"", response.read())

    def test_rejects_invalid_photo(self):
        request = Request(self.base_url + "/api/predict", data=b"not an image", method="POST")
        with self.assertRaises(HTTPError) as context:
            urlopen(request)
        self.assertEqual(context.exception.code, 400)
        self.assertIn("could not be read", json.load(context.exception)["error"])

    @unittest.skipUnless(MODEL_PATH.exists(), "Train the model first")
    def test_predicts_with_existing_model(self):
        path = next((ROOT / "apple_banana_dataset" / "test" / "apple").glob("*.jpg"))
        request = Request(self.base_url + "/api/predict", data=path.read_bytes(), method="POST")
        with urlopen(request, timeout=30) as response:
            result = json.load(response)
        self.assertEqual(result["fruit"], "apple")
        self.assertIn("apple", result["probabilities"])
        self.assertIn("nutrition", result["info"])


if __name__ == "__main__":
    unittest.main()
