import json
import unittest

import torch
from PIL import Image
from streamlit.testing.v1 import AppTest

from model import MODEL_PATH, ROOT, load_model, predict, prepare_image
from train import audit_dataset


class PipelineTests(unittest.TestCase):
    def test_duplicates_do_not_cross_retained_splits(self):
        records, report = audit_dataset(ROOT / "apple_banana_dataset")
        retained = {p.relative_to(ROOT / "apple_banana_dataset").as_posix()
                    for split in records.values() for p, _ in split}
        for duplicate in report["excluded_duplicates"]:
            self.assertNotIn(duplicate["excluded"], retained)
            self.assertIn(duplicate["retained"], retained)
        self.assertTrue(all(len(records[split]) for split in records))

    def test_transparent_portrait_keeps_shape_and_white_background(self):
        photo = Image.new("RGBA", (20, 80), (255, 0, 0, 255))
        prepared = prepare_image(photo)
        self.assertEqual(prepared.mode, "RGB")
        self.assertEqual(prepared.size, (96, 96))
        self.assertEqual(prepared.getpixel((0, 48)), (255, 255, 255))
        self.assertEqual(prepared.getpixel((48, 48)), (255, 0, 0))
        transparent = prepare_image(Image.new("RGBA", (20, 20), (0, 0, 0, 0)))
        self.assertEqual(transparent.getpixel((48, 48)), (255, 255, 255))

    @unittest.skipUnless(MODEL_PATH.exists(), "Train the model first")
    def test_saved_model_predicts_both_sample_classes(self):
        torch.set_num_threads(2)
        model = load_model()
        for fruit in ("apple", "banana"):
            path = next((ROOT / "apple_banana_dataset" / "test" / fruit).glob("*.jpg"))
            with Image.open(path) as photo:
                label, scores = predict(model, photo)
            self.assertEqual(label, fruit)
            self.assertAlmostEqual(sum(scores.values()), 1.0, places=5)


class InterfaceTests(unittest.TestCase):
    @unittest.skipUnless(MODEL_PATH.exists(), "Train the model first")
    def test_upload_landing(self):
        app = AppTest.from_file(str(ROOT / "app.py")).run(timeout=30)
        self.assertFalse(app.exception)
        self.assertEqual(app.title[0].value, "Apple or banana?")
        self.assertEqual(len(app.metric), 0)

    def test_facts_stay_stable_then_change_and_nutrition_has_serving(self):
        # Synthetic fixture only; actual fruit_info.json remains user-owned.
        script = '''
import app
app.show_fruit_details("apple", {
    "facts": ["Test fact A", "Test fact B"],
    "nutrition": {"serving": "test serving", "nutrients": {"Test nutrient": "12 g"}, "source": "Test source"}
}, "test-image")
'''
        app = AppTest.from_string(script).run(timeout=30)
        self.assertFalse(app.exception)
        first = app.info[0].value
        app.run(timeout=30)
        self.assertEqual(app.info[0].value, first)
        app.button[0].click().run(timeout=30)
        self.assertFalse(app.exception)
        self.assertNotEqual(app.info[0].value, first)
        self.assertIn("test serving", app.caption[0].value)
        self.assertEqual(app.table[0].value.iloc[0]["Amount"], "12 g")

    def test_empty_content_displays_pending_messages(self):
        app = AppTest.from_string('''
import app
app.show_fruit_details("banana", {
    "facts": [], "nutrition": {"serving": "", "nutrients": {}, "source": ""}
}, "test-image")
''').run(timeout=30)
        self.assertFalse(app.exception)
        self.assertEqual(len(app.info), 2)
        self.assertTrue(all("not been added yet" in entry.value for entry in app.info))


if __name__ == "__main__":
    unittest.main()
